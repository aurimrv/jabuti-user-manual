public class Sample {  
    public int div(int x, int y) {
        try {
            x = x / y;
        } catch (Exception e) {
            x = 0;
        } finally {
            y = 0;
        }
        return x;
    }  
}
