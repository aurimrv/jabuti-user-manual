public class BCI {
    int x;
    int[] v;
    static int y;

    public static void main(String[] args) {
        BCI r, s;
		
        // Different stack configurations
        r = new BCI();
        s = new BCI();
		
        (r.x == 0 ? r : s).x = 20;
		
        // Here there is no difference on the stack configuration
        if (r.x == 0) {
            r.x = 20;
        } else {
            s.x = 20;
        }

        // Class 1
        (new BCI()).x = 15;		
		
        r.m().x = 15;
		
		// Class 8
        int[][] f = new int[10][10];
		// Class 2
        r.x = f[1][2];
		
        // Class 3 and Class 7
        f[1][2] = 15;
		
        // Class 5
        r.y = 15;   // or
        BCI.y = 15;
		
        // Class 9
        BCI.y = s.x; 
        // Here there is also a use of the instance variabel v: L@2.v
        s.v[0] = 0;
		
        // Class 10
        s.x = BCI.y;
		
        // Classe 11
        int w = 0;
		
        if (w != 0) {
            w++;
        }
        // Here there is a use and a definition of L@2.x 
        // bu no IINC instruction is used...
        s.x++;
    }	
	
    public BCI m() {
        return this;
    }
}

